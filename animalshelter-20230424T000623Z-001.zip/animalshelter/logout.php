<?php
	session_start();
	session_destroy();
?>
<html>
<head>
	<title>Logout</title>
	<link rel="stylesheet" type="text/css" href="StyleSheets/logout.css">
</head>
<body>
	<div id="center-box">
		<h1>Indian Lake Animal Shelter</h1>
		<p>You have successfully logged out.</p>
	</div>
</body>
</html>
