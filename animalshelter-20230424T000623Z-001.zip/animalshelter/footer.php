<link rel="stylesheet" type="text/css" href="Footer/footer.css?v=2">

<footer>
  <p>&copy; 2023 Indian Animal Lake Shelter &bull; thelakeshelter@gmail.com &bull; 905-555-5555 &bull; Copyright @ ScrumMasters</p>
</footer>

